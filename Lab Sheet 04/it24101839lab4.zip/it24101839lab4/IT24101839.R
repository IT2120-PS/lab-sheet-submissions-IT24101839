setwd("C:\\Users\\it24101839\\Desktop\\it24101839")

# 1. Import dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

str(branch_data)


# 3. Boxplot for sales
boxplot(Sales_X1, 
        main = "Boxplot of Sales",
        horizontal = TRUE,
        ylab = "Sales (X1)", 
        col = "lightblue")

# 4
summary(Advertising_X2)
IQR(Advertising_X2)

# 5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  cat("Lower bound:", lower_bound, "\n")
  cat("Upper bound:", upper_bound, "\n")
  
  if (length(outliers) == 0) {
    cat("No outliers found.\n")
  } else {
    cat("Outliers:", paste(outliers, collapse = ", "), "\n")
  }
  
  return(outliers)
}

years_outliers <- find_outliers(Years_X3)
