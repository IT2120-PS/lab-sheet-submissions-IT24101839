setwd("C:\\Users\\madhu\\Desktop\\it24101839")

# Exercise 1 - Binomial Distribution (n=50, p=0.85)
n_ex1 <- 50
p_ex1 <- 0.85

# i. Distribution
cat("Exercise 1(i): X ~ Binomial(n =", n_ex1, ", p =", p_ex1, ")\n\n")

# ii. P(X >= 47) = 1 - P(X <= 46)
prob_ex1_ii <- pbinom(46, size = n_ex1, prob = p_ex1, lower.tail = FALSE)
cat("Exercise 1(ii): P(X >= 47) =", prob_ex1_ii, "\n\n")

# Exercise 2 - Poisson Distribution (lambda = 12)
lambda_ex2 <- 12

# i. & ii. Random Variable and Distribution
cat("Exercise 2(i): X is the number of customer calls received in an hour.\n")
cat("Exercise 2(ii): X ~ Poisson(lambda =", lambda_ex2, ")\n\n")

# iii. P(X = 15)
prob_ex2_iii <- dpois(15, lambda = lambda_ex2)
cat("Exercise 2(iii): P(X = 15) =", prob_ex2_iii, "\n\n")