setwd("C:\\Users\\DELL\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\PS_LAB-8")

#part 1
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
bag_weights <- weights$Weight.kg.
pop_mean <- mean(bag_weights)
pop_sd <- sd(bag_weights)

pop_mean
pop_sd

#part 2
set.seed(123)  # reproducibility
sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  sample_i <- sample(bag_weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
}
sample_means
sample_sds

#part 3
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)
mean_of_sample_means
sd_of_sample_means
theoretical_se <- pop_sd / sqrt(6)
theoretical_se
